print('this is \\\\ double backslash')
print('these are /\\/\\/\\/\\/\\ mountains ')
print('he is \t awesome')
print("\\\" \\n \\t \\'")