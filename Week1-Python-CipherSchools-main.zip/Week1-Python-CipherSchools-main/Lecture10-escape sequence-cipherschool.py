print("hello \"world\" world")
print('I\'m Abhishek')
#New line
print("line A")
print("line B")
print("line A\nline B\n line C")
#Tab
print("name\tAbhishek")
#backslash
print("this is backslash\\")
print("this is double backslash\\\\")
#backspace
print("hell\blo")