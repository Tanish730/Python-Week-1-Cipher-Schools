# pass statement
x = 18
if x >19:
    pass
