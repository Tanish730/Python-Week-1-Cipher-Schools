# check two conditions at same time
# and, or
name='Abhishek'
age = 19
# if name=='Abhishek' and age==19:
  #  print("condition true")
# else:
  #  print("condition false")

if name == 'Abhishek' or age > 19:
    print("condition true")
else:
    print("condition false ")
