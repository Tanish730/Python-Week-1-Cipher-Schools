# this is a comment 
print("Hello World!")
print('Abhishek Singh') #its my name 
print('12214677') #its my registration number
print('KOC09-RKOC0963') # its my section & roll number
'''I am learning python coding langaunge from CipherSchools
'''