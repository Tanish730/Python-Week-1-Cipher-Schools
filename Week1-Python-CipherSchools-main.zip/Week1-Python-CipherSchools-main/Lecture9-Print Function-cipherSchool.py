print("Hello world")
print('Hello world')
print("Hello'world'world")
print('Hello"world"world')
#error will occure if we use "" inside"" or '' inside ''
