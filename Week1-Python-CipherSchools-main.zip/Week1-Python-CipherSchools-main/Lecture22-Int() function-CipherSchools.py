num_1 = input("enter 1st no.") #8
num_2 = input("enter 2nd no.")#8
total = num_1 + num_2
print("toal no. is " + total) #88

num_1 = int(input("enter 1st no.")) #8
num_2 = int(input("enter 2nd no."))#8
total = num_1 + num_2
print("toal no. is " + str(total)) #16

num1 = str(4)
num2 = int("44")
num3 = float("33")
print(num2 + num3) #77