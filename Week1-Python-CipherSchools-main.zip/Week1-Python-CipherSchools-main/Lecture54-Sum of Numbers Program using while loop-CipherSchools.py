# sum 1 to 10
total = 0
i=1
while i <= 10:
    total+=i
    i+=1
print(total)
