name= "Abhi"
name += "shek"
print(name)
age=20
age-=1
print(age)
