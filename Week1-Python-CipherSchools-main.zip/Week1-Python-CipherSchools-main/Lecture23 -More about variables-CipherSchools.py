name, rollno = "Abhishek", "RKOC0963"
print("My name is "+ name + "\tMine roll is " + rollno )
q=w=e=2
print(q+w+e)