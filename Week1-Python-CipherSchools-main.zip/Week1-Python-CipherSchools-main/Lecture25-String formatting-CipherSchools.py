name = "Abhishek"
age = 19
print("my name is " + name + " and my age is " + str(age))
print("my name is {} and my age is {} ".format(name,age)) #string_formatting

Class = "tenth"
section = 9
print("your class is {} ,and section is {} ".format(Class,section)) #python3

print(f"hello {name} my age is {age}") #python3.6 easy to use
print(f"hello {name} my age is {age+45}") 

