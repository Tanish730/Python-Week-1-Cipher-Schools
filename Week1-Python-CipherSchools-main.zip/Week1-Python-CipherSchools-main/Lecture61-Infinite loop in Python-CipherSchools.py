# infinite loop
while True:
    print("hello world")
