number1 = 3142
print(number1)
name = 'Abhishek'
print(name)
_trial = 'username'
print(_trial)
who_are_you = 'i am Abhishek'
print(who_are_you)