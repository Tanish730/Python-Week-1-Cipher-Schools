name = "Abhishek"
# in keyword
# if with in
if 'H' in "Abhishek":
    print("A is present in name")
else:
    print("not present")
    
