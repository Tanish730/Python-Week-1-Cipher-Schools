print("LineA \nLineB")
print("LineA \\n LineB") #LineA \n LineB
print("LineA \tLineB") #LineA   LineB
print("LineA \\t LineB") #LineA \t LineB
print('This \'is\' backslash \\\\\\\\') #This 'is' backslash \\\\
print(" \' \" ") # ' "
print(" \\\" \\\' ") # \" \'