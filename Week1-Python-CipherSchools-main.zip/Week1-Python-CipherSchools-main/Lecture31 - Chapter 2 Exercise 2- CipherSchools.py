a=str(input("Enter your name:"))
print(f"reverse of your name is {a[::-1]}")
